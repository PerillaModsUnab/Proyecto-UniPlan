/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication9;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class RegisterScreen extends JFrame {
    private JTextField userField;
    private JPasswordField passwordField;
    private JButton registerButton;
    private JButton loginButton;

    public RegisterScreen() {
        setTitle("Register");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); 
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        
        JLabel textLabel = new JLabel("Ingresa a UNIPLAN", SwingConstants.CENTER);
        textLabel.setPreferredSize(new Dimension(200, 30));
        add(textLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;
        
        gbc.anchor = GridBagConstraints.CENTER;
        add(new JLabel("New Username:"), gbc);
        gbc.gridx++;
        userField = new JTextField();
        userField.setPreferredSize(new Dimension(150, 20));
        add(userField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        add(new JLabel("New Password:"), gbc);
        gbc.gridx++;
        passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(150, 20));
        add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel buttonPanel = new JPanel(new FlowLayout());
        registerButton = new JButton("Register");
        loginButton = new JButton("Login");
        registerButton.setPreferredSize(new Dimension(100, 30));
        loginButton.setPreferredSize(new Dimension(100, 30));
        buttonPanel.add(registerButton);
        buttonPanel.add(loginButton);
        add(buttonPanel, gbc);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();
                String password = new String(passwordField.getPassword());

                if (registerUser(username, password)) {
                    JOptionPane.showMessageDialog(null, "Registration successful!");
                    new LoginScreen();
                    dispose(); 
                } else {
                    JOptionPane.showMessageDialog(null, "Error registering user!");
                }
            }
        });

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginScreen();
                dispose(); 
            }
        });

        setVisible(true);
    }

    private boolean registerUser(String username, String password) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
            writer.write(username + "," + password);
            writer.newLine();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}