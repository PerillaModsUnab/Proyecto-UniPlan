package javaapplication9;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class UniPlan extends JFrame {
    private List<Evento> eventos;
    private JTextField eventoField;
    private JTextField horasField;
    private JLabel totalHorasLabel;
    private JLabel promedioSemanalLabel;
    private JLabel promedioMensualLabel;
    private JLabel promedioSemestralLabel;
    private JLabel promedioAnualLabel;
    private DefaultListModel<String> eventosListModel;
    private JList<String> eventosList;
    private JTextField idField;
    private JTextArea descripcionField;

    public UniPlan() {
        eventos = new ArrayList<>();
        setTitle("Uniplan");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        // Pestaña "Registro de Eventos y HL"
        JPanel registroPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        registroPanel.add(new JLabel("Nombre del Evento:"), gbc);

        eventoField = new JTextField(20);
        gbc.gridx = 1;
        registroPanel.add(eventoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        registroPanel.add(new JLabel("Horas Libres:"), gbc);

        horasField = new JTextField(10);
        gbc.gridx = 1;
        registroPanel.add(horasField, gbc);

        JButton registrarButton = new JButton("Registrar Evento");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        registroPanel.add(registrarButton, gbc);

        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarEvento();
            }
        });

        tabbedPane.addTab("Registro de Eventos y HL", registroPanel);

        // Pestaña "Horas Libres"
        JPanel horasLibresPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        totalHorasLabel = new JLabel("Total de Horas Libres: 0");
        promedioSemanalLabel = new JLabel("Promedio Semanal de Horas: 0");
        promedioMensualLabel = new JLabel("Promedio Mensual de Horas: 0");
        promedioSemestralLabel = new JLabel("Promedio Semestral de Horas: 0");
        promedioAnualLabel = new JLabel("Promedio Anual de Horas: 0");

        horasLibresPanel.add(totalHorasLabel);
        horasLibresPanel.add(promedioSemanalLabel);
        horasLibresPanel.add(promedioMensualLabel);
        horasLibresPanel.add(promedioSemestralLabel);
        horasLibresPanel.add(promedioAnualLabel);

        tabbedPane.addTab("Horas Libres", horasLibresPanel);

        // Pestaña "Lista de Eventos"
        JPanel listaEventosPanel = new JPanel(new BorderLayout());
        eventosListModel = new DefaultListModel<>();
        eventosList = new JList<>(eventosListModel);

        // Configurar el JScrollPane para que cubra una parte del centro y se expanda a medida que se agregan eventos
        JScrollPane scrollPane = new JScrollPane(eventosList);
        scrollPane.setPreferredSize(new Dimension(300, 150));  // Tamaño inicial de la lista

        // Configuramos un panel para el botón en la parte inferior
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton eliminarButton = new JButton("Eliminar Evento");
        buttonPanel.add(eliminarButton);

        listaEventosPanel.add(scrollPane, BorderLayout.CENTER);
        listaEventosPanel.add(buttonPanel, BorderLayout.SOUTH);

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarEventoSeleccionado();
            }
        });

        tabbedPane.addTab("Lista de Eventos", listaEventosPanel);

        // Pestaña "Sobre mí"
        JPanel sobreMiPanel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        sobreMiPanel.add(new JLabel("ID único:"), gbc);

        idField = new JTextField(20);
        gbc.gridx = 1;
        sobreMiPanel.add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        sobreMiPanel.add(new JLabel("Un poco más sobre ti:"), gbc);

        descripcionField = new JTextArea(5, 20);
        JScrollPane descripcionScrollPane = new JScrollPane(descripcionField);
        gbc.gridx = 1;
        sobreMiPanel.add(descripcionScrollPane, gbc);

        JButton borrarCuentaButton = new JButton("Borrar Cuenta");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        sobreMiPanel.add(borrarCuentaButton, gbc);

        borrarCuentaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarConfirmacionBorrarCuenta();
            }
        });

        tabbedPane.addTab("Sobre mí", sobreMiPanel);

        add(tabbedPane);
        setVisible(true);
    }

    private void mostrarConfirmacionBorrarCuenta() {
        int response = JOptionPane.showConfirmDialog(this, "¿Estás seguro de eliminar tu cuenta de manera permanente?", 
                                                     "Confirmación de Eliminación", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Cuenta eliminada correctamente.");
            dispose(); // Cerrar la aplicación
        }
    }

    private void registrarEvento() {
        String nombreEvento = eventoField.getText();
        int horasLibres;

        try {
            horasLibres = Integer.parseInt(horasField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingresa un número válido para las horas libres.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Evento nuevoEvento = new Evento(nombreEvento, horasLibres, Calendar.getInstance().getTime());
        eventos.add(nuevoEvento);
        eventosListModel.addElement(nombreEvento + " - " + horasLibres + " horas");
        actualizarHorasLibres();
        JOptionPane.showMessageDialog(this, "Evento registrado exitosamente.", "Registro Exitoso", JOptionPane.INFORMATION_MESSAGE);

        // Limpiar campos
        eventoField.setText("");
        horasField.setText("");
    }

    private void eliminarEventoSeleccionado() {
        int selectedIndex = eventosList.getSelectedIndex();
        if (selectedIndex != -1) {
            eventos.remove(selectedIndex);
            eventosListModel.remove(selectedIndex);
            actualizarHorasLibres();
            JOptionPane.showMessageDialog(this, "Evento eliminado correctamente.", "Eliminación Exitosa", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, selecciona un evento para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarHorasLibres() {
        int totalHoras = eventos.stream().mapToInt(Evento::getHorasLibres).sum();
        totalHorasLabel.setText("Total de Horas Libres: " + totalHoras);

        double promedioSemanal = calcularPromedioHoras(7);
        double promedioMensual = calcularPromedioHoras(30);
        double promedioSemestral = calcularPromedioHoras(182); // Aproximadamente 6 meses
        double promedioAnual = calcularPromedioHoras(365);

        promedioSemanalLabel.setText("Promedio Semanal de Horas: " + String.format("%.2f", promedioSemanal));
        promedioMensualLabel.setText("Promedio Mensual de Horas: " + String.format("%.2f", promedioMensual));
        promedioSemestralLabel.setText("Promedio Semestral de Horas: " + String.format("%.2f", promedioSemestral));
        promedioAnualLabel.setText("Promedio Anual de Horas: " + String.format("%.2f", promedioAnual));
    }

    private double calcularPromedioHoras(int dias) {
        int totalHoras = eventos.stream().mapToInt(Evento::getHorasLibres).sum();
        int totalDias = Math.min(dias, eventos.size());
        return totalDias > 0 ? (double) totalHoras / totalDias : 0;
    }

    public static void main(String[] args) {
        new UniPlan();
    }

    // Clase interna para representar un Evento
    class Evento {
        private String nombre;
        private int horasLibres;
        private java.util.Date fecha;

        public Evento(String nombre, int horasLibres, java.util.Date fecha) {
            this.nombre = nombre;
            this.horasLibres = horasLibres;
            this.fecha = fecha;
        }

        public int getHorasLibres() {
            return horasLibres;
        }

        public java.util.Date getFecha() {
            return fecha;
        }
    }
}